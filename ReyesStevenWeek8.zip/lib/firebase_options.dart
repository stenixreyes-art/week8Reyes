import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    throw UnsupportedError('Only web is supported on Zapp.run.');
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey:            'AIzaSyCw84MSX_NHUsVMsphD-zUhfw2dbUyOLO8',
    appId:             '1:923665679879:web:b0305b63c9832b897bcca2',
    messagingSenderId: '923665679879',
    projectId:         'todoappsample-4183b',
    authDomain:        'todoappsample-4183b.firebaseapp.com',
    storageBucket:     'todoappsample-4183b.firebasestorage.app',
  );
}